import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-currency',
  templateUrl: './travel-currency.component.html',
  styleUrls: ['./travel-currency.component.css']
})
export class TravelCurrencyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
