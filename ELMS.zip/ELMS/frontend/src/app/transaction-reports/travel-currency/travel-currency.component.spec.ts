import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelCurrencyComponent } from './travel-currency.component';

describe('TravelCurrencyComponent', () => {
  let component: TravelCurrencyComponent;
  let fixture: ComponentFixture<TravelCurrencyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelCurrencyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelCurrencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
