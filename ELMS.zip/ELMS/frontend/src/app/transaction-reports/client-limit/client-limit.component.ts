import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-limit',
  templateUrl: './client-limit.component.html',
  styleUrls: ['./client-limit.component.css']
})
export class ClientLimitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
