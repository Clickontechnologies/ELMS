import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorised-transactions',
  templateUrl: './authorised-transactions.component.html',
  styleUrls: ['./authorised-transactions.component.css']
})
export class AuthorisedTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
