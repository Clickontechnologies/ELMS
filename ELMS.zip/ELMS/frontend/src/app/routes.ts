import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AuthorisedTransactionsComponent } from './transaction-reports/authorised-transactions/authorised-transactions.component';
import { ClientLimitComponent } from './transaction-reports/client-limit/client-limit.component';
import { PendingTransactionsComponent } from './transaction-reports/pending-transactions/pending-transactions.component';
import { TravelCurrencyComponent } from './transaction-reports/travel-currency/travel-currency.component';
import { MaintenanceComponent } from './Admin/maintenance/maintenance.component';
import { ProfilesComponent } from './Admin/profiles/profiles.component';
import { UsersComponent } from './Admin/users/users.component';
import { AuditTrailComponent } from './Audit/audit-trail/audit-trail.component';
import { AuthorisationComponent } from './authorisation/authorisation.component';
import { NavigationComponent } from './navigation/navigation.component';
import { ValueComponent } from './value/value.component';

export const appRoutes: Routes = [
    {path: 'login', component: LoginComponent },
    {path: 'dashboard', component: DashboardComponent },
    {path: 'home', component: NavigationComponent },
    {path: 'register', component: RegisterComponent },
    {path: 'forgot-password', component: ForgotPasswordComponent },
    // API Test route
    {path: 'values', component: ValueComponent },

    // Transaction Reports
    {path: 'authorised-transactions', component: AuthorisedTransactionsComponent },
    {path: 'client-limit', component: ClientLimitComponent },
    {path: 'pending-transactions', component: PendingTransactionsComponent },
    {path: 'travel-currency', component: TravelCurrencyComponent },
    // Admin
    {path: 'maintenance', component: MaintenanceComponent },
    {path: 'profiles', component: ProfilesComponent },
    {path: 'users', component: UsersComponent },
    {path: 'audit', component: AuditTrailComponent },
    // Authorisation
    {path: 'authorisation', component: AuthorisationComponent },
    {path: '**', redirectTo: 'login', pathMatch: 'full' }
];
