import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { JwtModule } from '@auth0/angular-jwt';

// Material
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

// common imports
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NavComponent } from './nav/nav.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { PendingTransactionsComponent } from './transaction-reports/pending-transactions/pending-transactions.component';
import { AuthorisedTransactionsComponent } from './transaction-reports/authorised-transactions/authorised-transactions.component';
import { TravelCurrencyComponent } from './transaction-reports/travel-currency/travel-currency.component';
import { ClientLimitComponent } from './transaction-reports/client-limit/client-limit.component';
import { AuditTrailComponent } from './Audit/audit-trail/audit-trail.component';
import { UsersComponent } from './Admin/users/users.component';
import { ProfilesComponent } from './Admin/profiles/profiles.component';
import { MaintenanceComponent } from './Admin/maintenance/maintenance.component';
import { AuthorisationComponent } from './authorisation/authorisation.component';
import { NavigationComponent } from './navigation/navigation.component';
// API Test


// Providers
import { AuthService } from './_services/auth.service';
import { AlertifyService } from './_services/alertify.service';
import { appRoutes } from './routes';
import { ValueComponent } from './value/value.component';
import { MaterialModule } from './material/material.module';



export function tokenGetter() {
  return localStorage.getItem('token');
}


@NgModule({
   declarations: [
      AppComponent,
      LoginComponent,
      DashboardComponent,
      NavComponent,
      RegisterComponent,
      ForgotPasswordComponent,
      PendingTransactionsComponent,
      AuthorisedTransactionsComponent,
      TravelCurrencyComponent,
      ClientLimitComponent,
      AuditTrailComponent,
      UsersComponent,
      ProfilesComponent,
      MaintenanceComponent,
      AuthorisationComponent,
      ValueComponent,
      NavigationComponent
   ],
   imports: [
      BrowserModule,
      HttpClientModule,
      AppRoutingModule,
      BrowserAnimationsModule,
      FormsModule,
      RouterModule.forRoot(appRoutes),
      JwtModule.forRoot({
         config: {
           // tslint:disable-next-line: object-literal-shorthand
           tokenGetter: tokenGetter,
           whitelistedDomains: ['localhost:5000']
          //  blacklistedRoutes: ['localhost:5000/api/auth']
         }
       }),
      MaterialModule
     ],

  providers: [
    AuthService,
    AlertifyService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
